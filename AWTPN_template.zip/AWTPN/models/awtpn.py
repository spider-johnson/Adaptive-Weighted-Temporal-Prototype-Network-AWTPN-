
import torch.nn as nn
from .ses_module import SharedEmotionalSpace
from .tpn_module import TemporalPrototypeNetwork
from .awm_module import AdaptiveWeightModule

class AWTPN(nn.Module):
    def __init__(self, audio_dim, video_dim, shared_dim, num_classes,
                 ses_dropout=0.1, distance_scale_audio=1.0, distance_scale_video=1.0,
                 fusion_alpha_audio=0.3, fusion_beta_video=0.7):
        super().__init__()
        self.ses = SharedEmotionalSpace(audio_dim, video_dim, shared_dim, dropout=ses_dropout)
        self.tpn = TemporalPrototypeNetwork(shared_dim, num_classes)
        self.awm = AdaptiveWeightModule(shared_dim, fusion_alpha_audio, fusion_beta_video)
        self.classifier = nn.Linear(shared_dim, num_classes)
        self.distance_scale_audio = distance_scale_audio
        self.distance_scale_video = distance_scale_video

    def forward(self, audio_feats, video_feats):
        a, v = self.ses(audio_feats, video_feats)
        d_a = self.tpn.distances(a) * self.distance_scale_audio
        d_v = self.tpn.distances(v) * self.distance_scale_video
        fused, w_a, w_v = self.awm(a, v, d_a, d_v)
        logits = self.classifier(fused)
        return {"logits": logits, "a_proj": a, "v_proj": v,
                "dists_a": d_a, "dists_v": d_v, "w_a": w_a, "w_v": w_v,
                "prototypes": self.tpn.prototypes}
