
import torch
import torch.nn.functional as F

def align_loss(dists_a, dists_v, targets):
    B, _, C = dists_a.shape
    t = F.one_hot(targets, C).float().unsqueeze(1)
    la = (dists_a * t).sum(dim=-1).mean()
    lv = (dists_v * t).sum(dim=-1).mean()
    return la + lv

def intra_loss(a_proj, v_proj, targets):
    a_mean = a_proj.mean(dim=1)
    v_mean = v_proj.mean(dim=1)
    cos = 1 - F.cosine_similarity(a_mean, v_mean, dim=-1)
    return cos.mean()

def inter_loss(a_proj, v_proj, targets, margin=1.0):
    a_mean = a_proj.mean(dim=1)
    v_mean = v_proj.mean(dim=1)
    idx = torch.randperm(a_mean.size(0), device=a_mean.device)
    neg = v_mean[idx]
    cos_pos = F.cosine_similarity(a_mean, v_mean, dim=-1)
    cos_neg = F.cosine_similarity(a_mean, neg, dim=-1)
    return F.relu(margin + cos_pos - cos_neg).mean()

def contrastive_loss(a_proj, v_proj, margin=1.0):
    a_mean = a_proj.mean(dim=1)
    v_mean = v_proj.mean(dim=1)
    d = (a_mean - v_mean).pow(2).sum(dim=-1).sqrt().mean()
    idx = torch.randperm(a_mean.size(0), device=a_mean.device)
    d_neg = (a_mean - v_mean[idx]).pow(2).sum(dim=-1).sqrt()
    return d + F.relu(margin - d_neg).mean()

def ce_mse_losses(logits, targets):
    ce = F.cross_entropy(logits, targets)
    probs = logits.softmax(dim=-1)
    onehot = F.one_hot(targets, num_classes=probs.size(-1)).float()
    mse = (probs - onehot).pow(2).mean()
    return ce, mse

def total_loss(outputs, targets, weights, num_classes):
    la = align_loss(outputs["dists_a"], outputs["dists_v"], targets)
    li = intra_loss(outputs["a_proj"], outputs["v_proj"], targets)
    le = inter_loss(outputs["a_proj"], outputs["v_proj"], targets)
    lc = contrastive_loss(outputs["a_proj"], outputs["v_proj"])
    ce, mse = ce_mse_losses(outputs["logits"], targets)
    total = (weights["lambda_align"] * la +
             weights["lambda_intra"] * li +
             weights["lambda_inter"] * le +
             weights["lambda_contrast"] * lc +
             weights["eta_ce"] * ce +
             weights["eta_mse"] * mse)
    return total, {"align": la.item(), "intra": li.item(), "inter": le.item(),
                   "contrast": lc.item(), "ce": ce.item(), "mse": mse.item()}
