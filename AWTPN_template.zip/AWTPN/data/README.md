
# Data Instructions

Obtain datasets from official sources and place under `data/raw/<dataset>/`.

As a template, `data/preprocess.py` can generate dummy processed tensors to validate the pipeline:

```bash
python data/preprocess.py --dataset IEMOCAP
python data/preprocess.py --dataset MELD
python data/preprocess.py --dataset MOSEI
```
Processed tensors are saved under `data/processed/<dataset>/`:
- train.pt / val.pt / test.pt contain dicts with `audio_feats`, `video_feats`, `labels`.
