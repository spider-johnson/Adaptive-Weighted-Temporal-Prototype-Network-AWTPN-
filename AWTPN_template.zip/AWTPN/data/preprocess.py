
import argparse, os, torch, numpy as np, pathlib

def make_dummy_split(out_dir, num_classes=6, samples=64, M=30, N=30, Da=256, Dv=256):
    rng = np.random.default_rng(0)
    audio = torch.tensor(rng.standard_normal((samples, M, Da)), dtype=torch.float32)
    video = torch.tensor(rng.standard_normal((samples, N, Dv)), dtype=torch.float32)
    labels = torch.tensor(rng.integers(0, num_classes, size=(samples,)), dtype=torch.long)
    pathlib.Path(out_dir).mkdir(parents=True, exist_ok=True)
    for split in ["train.pt", "val.pt", "test.pt"]:
        torch.save({"audio_feats": audio, "video_feats": video, "labels": labels},
                   os.path.join(out_dir, split))
    print(f"Dummy splits written to {out_dir}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=str, required=True, choices=["IEMOCAP","MELD","MOSEI"])
    args = ap.parse_args()
    base = {"IEMOCAP":"data/processed/iemocap",
            "MELD":"data/processed/meld",
            "MOSEI":"data/processed/mosei"}[args.dataset]
    make_dummy_split(base, num_classes={"IEMOCAP":6,"MELD":7,"MOSEI":6}[args.dataset])
