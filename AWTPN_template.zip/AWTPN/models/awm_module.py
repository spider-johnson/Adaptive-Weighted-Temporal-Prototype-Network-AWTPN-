
import torch
import torch.nn as nn

class AdaptiveWeightModule(nn.Module):
    def __init__(self, shared_dim, alpha_audio=0.3, beta_video=0.7):
        super().__init__()
        self.alpha_audio = alpha_audio
        self.beta_video = beta_video
        self.q_a = nn.Linear(shared_dim, shared_dim, bias=False)
        self.k_a = nn.Linear(shared_dim, shared_dim, bias=False)
        self.q_v = nn.Linear(shared_dim, shared_dim, bias=False)
        self.k_v = nn.Linear(shared_dim, shared_dim, bias=False)

    def soft_attention(self, q, k):
        d = q.shape[-1] ** 0.5
        scores = (q @ k.transpose(-2, -1)) / d
        return scores.softmax(dim=-1)

    def forward(self, a_feats, v_feats, dists_a, dists_v):
        wa = (-dists_a.min(dim=-1).values).softmax(dim=-1)  # [B,M]
        wv = (-dists_v.min(dim=-1).values).softmax(dim=-1)  # [B,N]

        qa, ka = self.q_a(a_feats), self.k_a(a_feats)
        qv, kv = self.q_v(v_feats), self.k_v(v_feats)
        attn_a = self.soft_attention(qa, ka)  # [B,M,M]
        attn_v = self.soft_attention(qv, kv)  # [B,N,N]

        wa = (attn_a @ wa.unsqueeze(-1)).squeeze(-1)
        wv = (attn_v @ wv.unsqueeze(-1)).squeeze(-1)

        wa = wa / (wa.sum(dim=-1, keepdim=True) + 1e-8)
        wv = wv / (wv.sum(dim=-1, keepdim=True) + 1e-8)

        a_agg = (a_feats * wa.unsqueeze(-1)).sum(dim=1)
        v_agg = (v_feats * wv.unsqueeze(-1)).sum(dim=1)
        fused = self.alpha_audio * a_agg + self.beta_video * v_agg
        return fused, wa, wv
