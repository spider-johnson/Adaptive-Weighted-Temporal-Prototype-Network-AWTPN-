python train.py --config config/meld.yaml
python test.py --config config/meld.yaml --checkpoint checkpoints/awtpn_best.pth
