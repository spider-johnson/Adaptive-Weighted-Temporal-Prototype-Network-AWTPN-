
import torch
import torch.nn as nn

class TemporalPrototypeNetwork(nn.Module):
    def __init__(self, shared_dim, num_classes):
        super().__init__()
        self.prototypes = nn.Parameter(torch.randn(num_classes, shared_dim) * 0.02)

    def distances(self, feats):
        # feats: [B,T,D]; return squared Euclidean distance to prototypes: [B,T,C]
        x2 = (feats ** 2).sum(dim=-1, keepdim=True)                 # [B,T,1]
        p2 = (self.prototypes ** 2).sum(dim=-1).view(1,1,-1)        # [1,1,C]
        xp = feats @ self.prototypes.t()                            # [B,T,C]
        d2 = x2 + p2 - 2.0 * xp
        return d2.clamp_min(0.0)
