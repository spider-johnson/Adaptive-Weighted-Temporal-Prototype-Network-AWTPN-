
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix

def compute_metrics(y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    f1w = f1_score(y_true, y_pred, average='weighted')
    cm = confusion_matrix(y_true, y_pred)
    return {"w-ACC": acc, "w-F1": f1w, "confusion_matrix": cm}
