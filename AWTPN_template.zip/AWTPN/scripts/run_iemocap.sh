python train.py --config config/iemocap.yaml
python test.py --config config/iemocap.yaml --checkpoint checkpoints/awtpn_best.pth
