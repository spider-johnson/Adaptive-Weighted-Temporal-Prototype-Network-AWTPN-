
import torch.nn as nn

class SharedEmotionalSpace(nn.Module):
    def __init__(self, audio_dim, video_dim, shared_dim, dropout=0.1):
        super().__init__()
        self.audio_proj = nn.Sequential(nn.Linear(audio_dim, shared_dim), nn.ReLU(inplace=True), nn.Dropout(dropout))
        self.video_proj = nn.Sequential(nn.Linear(video_dim, shared_dim), nn.ReLU(inplace=True), nn.Dropout(dropout))

    def forward(self, a_feats, v_feats):
        return self.audio_proj(a_feats), self.video_proj(v_feats)
