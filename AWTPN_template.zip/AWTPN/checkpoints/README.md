Trained weights will be saved here as `awtpn_best.pth`.
