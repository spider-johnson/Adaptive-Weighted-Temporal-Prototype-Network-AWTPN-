python train.py --config config/mosei.yaml
python test.py --config config/mosei.yaml --checkpoint checkpoints/awtpn_best.pth
