Store logs and evaluation outputs (e.g., confusion matrices) here.
